var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'vithusha9993@gmail.com',
    pass: 'vithusha02
  }
});

var mailOptions = {
  from: 'vithusha9993@gmail.com',
  to: 'vinojan02abhimanyu@gmail.com',
  subject: 'Testing my nodemailer module',
  text: 'This is easy !'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
